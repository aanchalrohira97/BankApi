package com.example.bankapi.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.bankapi.model.Bank_Customer;

@Repository
public class Bank_Customer_DAOImplementation implements Bank_Customer_DAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public long save(Bank_Customer bank_customer) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Bank_Customer get(int login_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Bank_Customer> bank_customer_list() {
		List<Bank_Customer> list = sessionFactory.getCurrentSession().createQuery("from Bank_Customer").list();
	      return list;
	}

	@Override
	public void update(int id, Bank_Customer bank_customer) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

}
