package com.example.bankapi.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bankapi.dao.Bank_Customer_DAO;
import com.example.bankapi.model.Bank_Customer;

@Service
public class Bank_Customer_Service_Implementation implements Bank_Customer_Service{
	
	@Autowired
	private Bank_Customer_DAO BankCustDAO; 

	@Override
	public long save(Bank_Customer bank_customer) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Bank_Customer get(int login_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@Transactional
	public List<Bank_Customer> bank_customer_list() {
		return BankCustDAO.bank_customer_list();
		
	}

	@Override
	public void update(int id, Bank_Customer bank_customer) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

}
