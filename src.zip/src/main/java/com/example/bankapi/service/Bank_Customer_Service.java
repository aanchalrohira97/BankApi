package com.example.bankapi.service;

import java.util.List;

import com.example.bankapi.model.Bank_Customer;

public interface Bank_Customer_Service {
	
	//save the records 
		long save(Bank_Customer bank_customer);
		
		//retrieve a record
		Bank_Customer get(int login_id );
		
		//get all the records
		List<Bank_Customer> bank_customer_list();
		
		//update the record
		void update(int id, Bank_Customer bank_customer);
		
		//delete a record
		void delete(int id);

}
